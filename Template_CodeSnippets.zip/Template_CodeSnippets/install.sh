
cp -a CodeSnippets ~/Library/Developer/Xcode/UserData

sudo cp -a UCar\ Cocoa\ Touch\ Class.xctemplate  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/Library/Xcode/Templates/File\ Templates/Source

