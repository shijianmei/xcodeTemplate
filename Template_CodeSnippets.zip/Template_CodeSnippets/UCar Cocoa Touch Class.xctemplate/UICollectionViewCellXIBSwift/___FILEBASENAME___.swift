//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
